# 🚀 ETL Pipeline Automation

An automated **ETL (Extract, Transform, Load)** pipeline built with **Python, SQL, and AWS S3**.  
This pipeline reduces processing time by 30% through optimized SQL queries and Pandas transformations.

## 📂 Project Structure
- `src/` → Core ETL scripts (extract, transform, load, main)
- `config/` → Configurations (DB credentials, API URLs, S3 paths)
- `data/` → Sample input/output data

## ⚡ Features
- Extracts from:
  - CSV files
  - REST APIs
  - AWS S3
- Transforms using **Pandas**
- Loads into SQL database
- Modular & Config-driven

## 🔧 Setup
```bash
git clone https://github.com/your-username/etl-pipeline-automation.git
cd etl-pipeline-automation
pip install -r requirements.txt
```

## ▶️ Run
```bash
python src/main.py
```

## 🛠 Tools
- Python (Pandas)
- SQLAlchemy
- AWS S3 (Boto3)
- Requests

## 📜 License
MIT License
