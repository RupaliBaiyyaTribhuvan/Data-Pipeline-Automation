import sqlalchemy
import pandas as pd

def load_to_sql(df: pd.DataFrame, connection_string: str, table_name: str):
    engine = sqlalchemy.create_engine(connection_string)
    df.to_sql(table_name, con=engine, if_exists="replace", index=False)
