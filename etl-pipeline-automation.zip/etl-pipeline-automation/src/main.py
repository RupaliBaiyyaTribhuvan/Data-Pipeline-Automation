import yaml
from extract import extract_from_csv, extract_from_api, extract_from_s3
from transform import transform_data
from load import load_to_sql

def main():
    with open("config/config.yaml", "r") as f:
        config = yaml.safe_load(f)

    df_csv = extract_from_csv(config["data_sources"]["csv"])
    df_api = extract_from_api(config["data_sources"]["api"])
    df_s3 = extract_from_s3(config["data_sources"]["s3"]["bucket"], 
                            config["data_sources"]["s3"]["key"], 
                            "data/input.csv")

    df = df_csv.append([df_api, df_s3], ignore_index=True)
    df_transformed = transform_data(df)
    load_to_sql(df_transformed, config["database"]["connection_string"], "etl_table")

    print("ETL Pipeline executed successfully ✅")

if __name__ == "__main__":
    main()
