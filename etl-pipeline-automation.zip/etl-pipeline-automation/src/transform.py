import pandas as pd

def transform_data(df: pd.DataFrame) -> pd.DataFrame:
    df = df.dropna()
    df.columns = [col.strip().lower().replace(" ", "_") for col in df.columns]
    return df
