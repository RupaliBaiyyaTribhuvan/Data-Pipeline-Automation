import pandas as pd
import boto3
import requests

def extract_from_csv(file_path: str) -> pd.DataFrame:
    return pd.read_csv(file_path)

def extract_from_api(api_url: str) -> pd.DataFrame:
    response = requests.get(api_url)
    response.raise_for_status()
    return pd.DataFrame(response.json())

def extract_from_s3(bucket: str, key: str, local_path: str) -> pd.DataFrame:
    s3 = boto3.client("s3")
    s3.download_file(bucket, key, local_path)
    return pd.read_csv(local_path)
